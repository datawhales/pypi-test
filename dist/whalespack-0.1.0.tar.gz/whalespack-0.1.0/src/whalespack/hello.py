def add_one(number: int) -> int:
    return number + 1


def say_hello() -> None:
    print("Hello! This is 'hello' module from whalespack package!")


if __name__ == "__main__":
    say_hello()
